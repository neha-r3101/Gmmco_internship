/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

package com.microsoft.device.dualscreen.testing.sample.utils

fun withWidth(width: Int) = WidthMatcher(width)