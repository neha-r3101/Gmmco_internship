/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

package com.microsoft.device.dualscreen.tabs

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Parcel
import android.os.Parcelable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import androidx.activity.ComponentActivity
import androidx.core.view.animation.PathInterpolatorCompat
import androidx.customview.view.AbsSavedState
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.transition.ChangeBounds
import androidx.transition.Transition
import androidx.transition.TransitionManager
import androidx.window.layout.WindowInfoTracker
import androidx.window.layout.WindowLayoutInfo
import com.google.android.material.tabs.TabLayout
import com.microsoft.device.dualscreen.utils.wm.DisplayPosition
import com.microsoft.device.dualscreen.utils.wm.OnSwipeListener
import com.microsoft.device.dualscreen.utils.wm.ScreenMode
import com.microsoft.device.dualscreen.utils.wm.createHalfTransparentBackground
import com.microsoft.device.dualscreen.utils.wm.extractFoldingFeatureRect
import com.microsoft.device.dualscreen.utils.wm.getWindowVisibleDisplayFrame
import com.microsoft.device.dualscreen.utils.wm.isFoldingFeatureVertical
import com.microsoft.device.dualscreen.utils.wm.isInDualMode
import com.microsoft.device.dualscreen.utils.wm.locationOnScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * A sub class of the TabLayout that can position its children in different ways when the application is spanned on both screens.
 * Using the [arrangeButtons] and [displayPosition] the children can be split in any way between the two screens.
 * If one of the screens doesn't contain any button, its background can be made transparent.
 */
open class TabLayout : TabLayout {

    constructor(context: Context) : super(context) {
        this.registerWindowInfoFlow()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        this.registerWindowInfoFlow()
        extractAttributes(context, attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        this.registerWindowInfoFlow()
        extractAttributes(context, attrs)
    }

    private var job: Job? = null
    private var startScreenWidth = -1
    private var endScreenWidth = -1
    private var totalScreenWidth = -1
    private var hingeWidth = -1

    private var screenMode = ScreenMode.DUAL_SCREEN
    private var windowLayoutInfo: WindowLayoutInfo? = null

    private var initialBackground: Drawable? = null
    private var startBtnCount: Int = -1
    private var endBtnCount: Int = -1
    private var defaultChildWidth = -1

    private fun normalizeFoldingFeatureRectForView(): Rect {
        return windowLayoutInfo.extractFoldingFeatureRect().apply {
            offset(-locationOnScreen.x, 0)
        }
    }

    private fun registerWindowInfoFlow() {
        val activity = (context as? ComponentActivity)
            ?: throw RuntimeException("Context must implement androidx.activity.ComponentActivity!")
        job = activity.lifecycleScope.launch(Dispatchers.Main) {
            activity.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                WindowInfoTracker.getOrCreate(activity)
                    .windowLayoutInfo(activity)
                    .collect { info ->
                        windowLayoutInfo = info
                        onInfoLayoutChanged()
                    }
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        job?.cancel()
    }

    private fun onInfoLayoutChanged() {
        setScreenParameters()
        tryUpdateBackground()

        val changeBounds: Transition = ChangeBounds()
        changeBounds.duration = 300L
        changeBounds.interpolator = PathInterpolatorCompat.create(0.2f, 0f, 0f, 1f)
        TransitionManager.beginDelayedTransition(this@TabLayout, changeBounds)
        requestLayout()
    }

    private var onSwipeListener: OnSwipeListener = object : OnSwipeListener(context) {
        override fun onSwipeLeft() {
            super.onSwipeLeft()
            if (allowFlingGesture) {
                displayPosition = DisplayPosition.START
            }
        }

        override fun onSwipeRight() {
            super.onSwipeRight()
            if (allowFlingGesture) {
                displayPosition = DisplayPosition.END
            }
        }
    }

    /**
     * Determines where to display the bottom navigation buttons when the application is spanned on both screens.
     * The options are [DisplayPosition.START], [DisplayPosition.END] or [DisplayPosition.DUAL]
     */
    var displayPosition: DisplayPosition = DisplayPosition.DUAL
        set(value) {
            updateDisplayPosition(value)
            field = value
        }

    /**
     * Allows the buttons to be moved to [DisplayPosition.START] or [DisplayPosition.END] with a swipe gesture.
     */
    var allowFlingGesture: Boolean = true

    /**
     * When the application is spanned and there are no buttons on a screen, the background on that screen will be made transparent.
     */
    var useTransparentBackground: Boolean = true
        set(value) {
            field = value
            tryUpdateBackground()
        }

    init {
        tryUpdateBackground()
    }

    private fun extractAttributes(context: Context, attrs: AttributeSet?) {
        val styledAttributes =
            context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.ScreenManagerAttrs,
                0,
                0
            )
        try {
            screenMode = ScreenMode.fromId(
                styledAttributes.getResourceId(
                    R.styleable.ScreenManagerAttrs_tools_application_mode,
                    ScreenMode.DUAL_SCREEN.ordinal
                )
            )
            displayPosition = DisplayPosition.fromResId(
                styledAttributes.getInt(
                    R.styleable.ScreenManagerAttrs_display_position,
                    DisplayPosition.DUAL.ordinal
                )
            )
            allowFlingGesture =
                styledAttributes.getBoolean(
                    R.styleable.ScreenManagerAttrs_allowFlingGesture,
                    allowFlingGesture
                )
            useTransparentBackground =
                styledAttributes.getBoolean(
                    R.styleable.ScreenManagerAttrs_useTransparentBackground,
                    useTransparentBackground
                )
        } finally {
            styledAttributes.recycle()
        }
    }

    private fun setScreenParameters() {
        totalScreenWidth = context.getWindowVisibleDisplayFrame().width()
        normalizeFoldingFeatureRectForView().let {
            hingeWidth = it.width()
            startScreenWidth = it.left
            endScreenWidth = totalScreenWidth - it.right
        }
    }

    private fun shouldSplit(): Boolean {
        return windowLayoutInfo.isInDualMode() && windowLayoutInfo.isFoldingFeatureVertical()
    }

    /**
     * When the application is in spanned mode the buttons can be split between the screens.
     */
    fun arrangeButtons(startBtnCount: Int, endBtnCount: Int) {
        val child = getChildAt(0) as LinearLayout
        if (!shouldSplit()) {
            if (child.doesChildCountMatch(startBtnCount, endBtnCount)) {
                syncBtnCount(startBtnCount, endBtnCount)
            }
            return
        }

        if (this.startBtnCount == startBtnCount && this.endBtnCount == endBtnCount) {
            return
        }

        if (child.doesChildCountMatch(startBtnCount, endBtnCount)) {
            syncBtnCount(startBtnCount, endBtnCount)
            child.arrangeOnScreen(0, startBtnCount - 1)
            child.arrangeOnScreen(startBtnCount, startBtnCount + endBtnCount - 1)
            getTabAt(selectedTabPosition)!!.select()
            tryUpdateBackground()
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        if (!shouldSplit()) {
            return
        }

        val child = getChildAt(0) as LinearLayout
        child.layout(0, 0, this.width, this.height)
        child.redoLayout(startBtnCount, endBtnCount)
    }

    private fun LinearLayout.redoLayout(firstScreen: Int, secondScreen: Int) {
        if (childCount != firstScreen + secondScreen) {
            return
        }
        if (childCount == 0) {
            return
        }
        arrangeOnScreen(0, firstScreen - 1)
        arrangeOnScreen(firstScreen, firstScreen + secondScreen - 1)
    }

    private fun LinearLayout.arrangeOnScreen(firstBtnIndex: Int, secondBtnIndex: Int) {
        val buttonsCount = secondBtnIndex - firstBtnIndex + 1
        if (buttonsCount == 0) {
            return
        }

        val startPoint =
            if (firstBtnIndex != 0 || displayPosition == DisplayPosition.END) {
                normalizeFoldingFeatureRectForView().right
            } else {
                0
            }
        val screenWidth =
            if (firstBtnIndex != 0 || displayPosition == DisplayPosition.END) {
                endScreenWidth
            } else {
                startScreenWidth
            }

        if (defaultChildWidth == -1) {
            defaultChildWidth = getChildAt(0).measuredWidth
        }

        val childWidth = if (buttonsCount * defaultChildWidth > screenWidth) {
            screenWidth / buttonsCount
        } else {
            defaultChildWidth
        }

        val childMargin = (screenWidth - childWidth * buttonsCount) / (buttonsCount + 1)

        for (i in firstBtnIndex..secondBtnIndex) {
            val btnNoOnScreen = i - firstBtnIndex
            val child = getChildAt(i)
            val childLeft =
                startPoint + btnNoOnScreen * childWidth + (btnNoOnScreen + 1) * childMargin
            setChildLayout(child, childLeft, childWidth)
        }
    }

    private fun LinearLayout.doesChildCountMatch(startBtnCount: Int, endBtnCount: Int): Boolean {
        return startBtnCount >= 0 && endBtnCount >= 0 && childCount == startBtnCount + endBtnCount
    }

    private fun setChildLayout(child: View, left: Int, childWidth: Int) {
        child.layout(left, child.top, left + childWidth, child.bottom)
    }

    private fun updateDisplayPosition(newPosition: DisplayPosition) {
        if (!shouldSplit()) {
            return
        }

        if (displayPosition == newPosition) {
            return
        }
        val btnCount = (getChildAt(0) as LinearLayout).childCount

        if (newPosition == DisplayPosition.START) {
            arrangeButtons(btnCount, 0)
        }
        if (newPosition == DisplayPosition.END) {
            arrangeButtons(0, btnCount)
        }
    }

    /**
     * Synchronize the [displayPosition] with the [startBtnCount] and [endBtnCount].
     */
    private fun syncBtnCount(startBtnCount: Int, endBtnCount: Int) {
        this.startBtnCount = startBtnCount
        this.endBtnCount = endBtnCount

        if (startBtnCount == 0 && endBtnCount != 0) {
            displayPosition = DisplayPosition.END
        }

        if (endBtnCount == 0 && startBtnCount != 0) {
            displayPosition = DisplayPosition.START
        }

        if (startBtnCount > 0 && endBtnCount > 0) {
            displayPosition = DisplayPosition.DUAL
        }
    }

    private fun hasButtonsOnBothScreens(): Boolean {
        return startBtnCount > 0 && endBtnCount > 0
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!allowFlingGesture) {
            return super.onInterceptTouchEvent(ev)
        }
        onSwipeListener.onTouchEvent(ev)

        if (onSwipeListener.onInterceptTouchEvent(ev)) {
            return true
        }
        return super.onInterceptTouchEvent(ev)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent?): Boolean {
        if (!allowFlingGesture) {
            return super.onTouchEvent(ev)
        }
        return onSwipeListener.onTouchEvent(ev)
    }

    override fun setBackground(background: Drawable?) {
        if (initialBackground == null) {
            initialBackground = background
        }
        super.setBackground(background)
    }

    private fun tryUpdateBackground() {
        if (!shouldSplit() ||
            childCount != 1 || !useTransparentBackground || hasButtonsOnBothScreens()
        ) {
            if (background != initialBackground) {
                background = initialBackground
            }
        } else {
            background = if (displayPosition == DisplayPosition.DUAL) {
                initialBackground
            } else {
                createHalfTransparentBackground(
                    initialBackground,
                    displayPosition,
                    normalizeFoldingFeatureRectForView(),
                    totalScreenWidth
                )
            }
        }
    }

    override fun onSaveInstanceState(): Parcelable? {
        val superState: Parcelable? = super.onSaveInstanceState()
        superState?.let {
            val state = SavedState(superState)
            state.allowFlingGesture = this.allowFlingGesture
            state.useTransparentBackground = this.useTransparentBackground
            state.displayPosition = this.displayPosition
            state.startBtnCount = this.startBtnCount
            state.endBtnCount = this.endBtnCount
            return state
        } ?: run {
            return superState
        }
    }

    override fun onRestoreInstanceState(state: Parcelable) {
        when (state) {
            is SavedState -> {
                super.onRestoreInstanceState(state.superState)
                this.allowFlingGesture = state.allowFlingGesture
                this.useTransparentBackground = state.useTransparentBackground
                this.displayPosition = state.displayPosition
                this.startBtnCount = state.startBtnCount
                this.endBtnCount = state.endBtnCount
            }
            else -> {
                super.onRestoreInstanceState(state)
            }
        }
    }

    internal class SavedState : AbsSavedState {
        var allowFlingGesture: Boolean = true
        var useTransparentBackground: Boolean = true
        var displayPosition: DisplayPosition = DisplayPosition.DUAL
        var startBtnCount: Int = -1
        var endBtnCount: Int = -1

        constructor(superState: Parcelable) : super(superState)

        constructor(source: Parcel, loader: ClassLoader?) : super(source, loader) {
            allowFlingGesture = source.readInt() == 1
            useTransparentBackground = source.readInt() == 1
            displayPosition = DisplayPosition.fromResId(source.readInt())
            startBtnCount = source.readInt()
            endBtnCount = source.readInt()
        }

        override fun writeToParcel(out: Parcel, flags: Int) {
            super.writeToParcel(out, flags)
            out.writeInt(if (allowFlingGesture) 1 else 0)
            out.writeInt(if (useTransparentBackground) 1 else 0)
            out.writeInt(displayPosition.id)
            out.writeInt(startBtnCount)
            out.writeInt(endBtnCount)
        }

        companion object {
            @JvmField
            val CREATOR: Parcelable.ClassLoaderCreator<SavedState> =
                object : Parcelable.ClassLoaderCreator<SavedState> {
                    override fun createFromParcel(source: Parcel, loader: ClassLoader): SavedState {
                        return SavedState(source, loader)
                    }

                    override fun createFromParcel(source: Parcel): SavedState {
                        return SavedState(source, null)
                    }

                    override fun newArray(size: Int): Array<SavedState> {
                        return newArray(size)
                    }
                }
        }
    }
}