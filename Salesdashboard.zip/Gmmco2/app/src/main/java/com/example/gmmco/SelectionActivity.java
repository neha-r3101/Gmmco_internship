package com.example.gmmco;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class SelectionActivity extends AppCompatActivity {

    Button profileButton, dashboardButton;
    ImageButton supportButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        profileButton = findViewById(R.id.profileButton);
        dashboardButton = findViewById(R.id.dashboardButton);
        supportButton = findViewById(R.id.supportButton);

        profileButton.setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
        });

        dashboardButton.setOnClickListener(v -> {
            startActivity(new Intent(this, DashboardActivity.class));
        });

        supportButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Need Support?")
                    .setItems(new CharSequence[]{"🤖 Chatbot", "📞 Call Support"}, (dialog, which) -> {
                        if (which == 0) {
                            Toast.makeText(this, "Launching Chatbot...", Toast.LENGTH_SHORT).show();
                            // Optionally: startActivity(new Intent(this, ChatbotActivity.class));
                        } else {
                            Intent callIntent = new Intent(Intent.ACTION_DIAL);
                            callIntent.setData(Uri.parse("tel:1800123456"));
                            startActivity(callIntent);
                        }
                    })
                    .show();
        });
    }
}
