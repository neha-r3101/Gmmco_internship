package com.example.gmmco;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    TextView userNameText, emailText, roleText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        userNameText = findViewById(R.id.userNameText);
        emailText = findViewById(R.id.emailText);
        roleText = findViewById(R.id.roleText);

        userNameText.setText("Neha Ravindran");
        emailText.setText("neha.ravindran@outlook.com");
        roleText.setText("Role: Student Developer");

        Button backButton = findViewById(R.id.backToHomeButton);
        backButton.setOnClickListener(v -> finish());
    }
}
