package com.example.gmmco;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DashboardActivity extends AppCompatActivity {

    private static final String URL = "http://10.0.2.2:3000/get-asset-report";
    private RecyclerView recyclerView;
    private DashboardAdapter adapter;
    private final List<ModelItem> eList = new ArrayList<>();
    private TextView totalUnitsText;

    // ✅ Add longer timeout to prevent network error
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .callTimeout(60, TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        recyclerView = findViewById(R.id.recyclerView);
        totalUnitsText = findViewById(R.id.totalUnitsText);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DashboardAdapter(this, eList);
        recyclerView.setAdapter(adapter);

        fetchBackendData();
    }

    private void fetchBackendData() {
        Request request = new Request.Builder().url(URL).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                try {
                    if (!response.isSuccessful()) {
                        runOnUiThread(() -> Toast.makeText(DashboardActivity.this, "❌ Server Error", Toast.LENGTH_LONG).show());
                        return;
                    }

                    String jsonData = response.body().string();
                    JSONArray jsonArray = new JSONArray(jsonData);
                    Log.d("FETCH", "✅ Items received: " + jsonArray.length());

                    Map<String, ModelItem> groupedMap = new HashMap<>();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);

                        String modelName = obj.optString("Product Number", "").trim();
                        if (modelName.isEmpty())
                            modelName = obj.optString("Name", "").trim();
                        if (modelName.isEmpty()) continue;

                        String sbu = obj.optString("SBU", "").toLowerCase(Locale.ROOT).trim();

                        if (sbu.isEmpty()) {
                            String branch = obj.optString("Plant Associated(GMMCO Branch)", "").toLowerCase(Locale.ROOT);
                            if (branch.contains("satna") || branch.contains("jabalpur") || branch.contains("bhopal")) {
                                sbu = "north";
                            } else if (branch.contains("nagpur") || branch.contains("raipur") ||
                                    branch.contains("vizag") || branch.contains("vijayawada") ||
                                    branch.contains("kurnool") || branch.contains("hyderabad")) {
                                sbu = "east";
                            } else if (branch.contains("coimbatore") || branch.contains("chennai")) {
                                sbu = "south";
                            } else if (branch.contains("pune") || branch.contains("mumbai") || branch.contains("surat")) {
                                sbu = "west";
                            }
                        }

                        if (!Arrays.asList("north", "south", "east", "west").contains(sbu)) {
                            Log.w("FETCH", "⚠️ Unknown SBU: " + sbu + " for model: " + modelName);
                            continue;
                        }

                        ModelItem item = groupedMap.getOrDefault(modelName, new ModelItem());
                        item.setModel(modelName);
                        item.setGroup("GCI");

                        switch (sbu) {
                            case "north": item.setNorth(item.getNorth() + 1); break;
                            case "south": item.setSouth(item.getSouth() + 1); break;
                            case "east":  item.setEast(item.getEast() + 1); break;
                            case "west":  item.setWest(item.getWest() + 1); break;
                        }

                        groupedMap.put(modelName, item);
                    }

                    Log.d("FETCH", "✅ Grouped models: " + groupedMap.size());

                    eList.clear();
                    eList.addAll(groupedMap.values());

                    runOnUiThread(() -> {
                        adapter.notifyDataSetChanged();
                        updateTotalUnits();
                    });

                } catch (Exception e) {
                    Log.e("Dashboard", "❌ Parsing error", e);
                    runOnUiThread(() -> Toast.makeText(DashboardActivity.this, "❌ Parsing failed", Toast.LENGTH_SHORT).show());
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("FETCH", "❌ Network error: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(DashboardActivity.this, "❌ Network error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void updateTotalUnits() {
        int total = 0;
        for (ModelItem item : eList) {
            total += item.getNorth() + item.getSouth() + item.getEast() + item.getWest();
        }
        totalUnitsText.setText("Total Units Sold: " + total);
    }
}
