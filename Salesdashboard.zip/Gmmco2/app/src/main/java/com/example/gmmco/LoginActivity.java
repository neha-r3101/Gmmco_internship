package com.example.gmmco;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.microsoft.identity.client.AuthenticationCallback;
import com.microsoft.identity.client.IAuthenticationResult;
import com.microsoft.identity.client.ISingleAccountPublicClientApplication;
import com.microsoft.identity.client.PublicClientApplication;
import com.microsoft.identity.client.exception.MsalException;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {

    private ISingleAccountPublicClientApplication mSingleAccountApp;
    private static final String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button signInButton = findViewById(R.id.btnMicrosoftSignIn);
        signInButton.setEnabled(false); // Enable after MSAL init

        PublicClientApplication.createSingleAccountPublicClientApplication(
                this,
                R.raw.auth_config_single_account,
                new PublicClientApplication.ISingleAccountApplicationCreatedListener() {
                    @Override
                    public void onCreated(ISingleAccountPublicClientApplication application) {
                        mSingleAccountApp = application;
                        signInButton.setEnabled(true);
                        signInButton.setOnClickListener(v -> signIn());
                    }

                    @Override
                    public void onError(MsalException exception) {
                        Log.e(TAG, "MSAL init failed", exception);
                        Toast.makeText(LoginActivity.this, "MSAL init failed", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    private void signIn() {
        if (mSingleAccountApp == null) {
            Toast.makeText(this, "MSAL not initialized", Toast.LENGTH_SHORT).show();
            return;
        }

        mSingleAccountApp.signIn(this, null, new String[]{"User.Read"},
                new AuthenticationCallback() {
                    @Override
                    public void onSuccess(IAuthenticationResult authenticationResult) {
                        String accessToken = authenticationResult.getAccessToken();
                        callGraphApi(accessToken);
                    }

                    @Override
                    public void onError(MsalException e) {
                        Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Login error", e);
                    }

                    @Override
                    public void onCancel() {
                        Toast.makeText(LoginActivity.this, "Login Cancelled", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void callGraphApi(String accessToken) {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://graph.microsoft.com/v1.0/me")
                .addHeader("Authorization", "Bearer " + accessToken)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, "Graph API call failed", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Graph API error", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String responseData = response.body().string();
                    try {
                        JSONObject json = new JSONObject(responseData);
                        String email = json.optString("mail"); // or "userPrincipalName" if "mail" is null

                        if (email == null || email.isEmpty()) {
                            email = json.optString("userPrincipalName");
                        }

                        String finalEmail = email;

                        runOnUiThread(() -> {
                            if (finalEmail != null && !finalEmail.isEmpty()) {
                                UserRepository userRepository = new UserRepository(LoginActivity.this);
                                userRepository.insertUser(finalEmail);

                                Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(LoginActivity.this, SelectionActivity.class));
                                finish();
                            } else {
                                Toast.makeText(LoginActivity.this, "Email not found", Toast.LENGTH_SHORT).show();
                            }
                        });

                    } catch (Exception e) {
                        Log.e(TAG, "Failed to parse Graph response", e);
                    }
                } else {
                    Log.e(TAG, "Graph API failed: " + response.code());
                }
            }
        });
    }
}
