package com.example.gmmco;

import android.util.Log;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;

public class AssetService {

    private static final String TAG = "AssetService";
    private static final String BASE_URL = "http://10.0.2.2:3000";  // for Android Emulator

    public static void fetchAssetReport(Callback callback) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASE_URL + "/get-asset-report")
                .build();

        client.newCall(request).enqueue(callback);
    }
}
