package com.example.gmmco;

public class ModelItem {

    private String group;
    private String model;
    private int imageRes;         // R.drawable.*
    private String imageUrl;
    private int north, south, east, west;

    public ModelItem() { }

    public ModelItem(String group, String model,
                     int imageRes, String imageUrl,
                     int north, int south, int east, int west) {
        this.group = group;
        this.model = model;
        this.imageRes = imageRes;
        this.imageUrl = imageUrl;
        this.north = north;
        this.south = south;
        this.east = east;
        this.west = west;
    }

    // ---------- GETTERS ----------
    public String getGroup()    { return group; }
    public String getModel()    { return model; }
    public int    getImageRes() { return imageRes; }
    public String getImageUrl() { return imageUrl; }
    public int    getNorth()    { return north; }
    public int    getSouth()    { return south; }
    public int    getEast()     { return east; }
    public int    getWest()     { return west; }
    public int    getTotal()    { return north + south + east + west; }

    // ---------- SETTERS ----------
    public void setGroup(String g)       { group = g; }

    public void setModel(String rawModel) {
        String normalized = normalizeModel(rawModel);
        this.model = normalized;
        this.imageRes = assignImageRes(normalized);
    }

    public void setImageRes(int res)     { imageRes = res; }
    public void setImageUrl(String url)  { imageUrl = url; }
    public void setNorth(int v)          { north = v; }
    public void setSouth(int v)          { south = v; }
    public void setEast(int v)           { east = v; }
    public void setWest(int v)           { west = v; }

    // ---------- Helper: Normalize Model Name ----------
    private String normalizeModel(String name) {
        if (name == null) return "Unknown";
        name = name.toLowerCase();

        if (name.contains("backhoe")) return "Backhoe Loader";
        if (name.contains("320d3")) return "320D3 Excavator";
        if (name.contains("323d3")) return "323D3 Excavator";
        if (name.contains("120gc")) return "120GC Motor Grader";
        if (name.contains("953k")) return "953K Wheel Loader";
        if (name.contains("216b3")) return "216B3 Skid Loader";
        if (name.contains("c12")) return "C12 Engine";
        if (name.contains("trans 950l")) return "TRANS 950L";
        if (name.contains("wheel loader")) return "Wheel Loader";

        return capitalizeWords(name.trim());
    }

    // ---------- Helper: Assign Image Based on Model ----------
    private int assignImageRes(String normalizedModel) {
        if (normalizedModel == null) return R.drawable.img_placeholder;

        switch (normalizedModel) {
            case "Backhoe Loader":        return R.drawable.img_424_backhoe_loader;
            case "320D3 Excavator":       return R.drawable.img_320d3gc;
            case "323D3 Excavator":       return R.drawable.img_323d3_excavator;
            case "120GC Motor Grader":    return R.drawable.img_120g_motor_grader;
            case "953K Wheel Loader":     return R.drawable.img_2021e_wheel_loader;
            case "216B3 Skid Loader":     return R.drawable.img_216b3_skid_loader;
            case "C12 Engine":            return R.drawable.img_placeholder; // Add specific image if needed
            case "TRANS 950L":            return R.drawable.img_placeholder;
            case "Wheel Loader":          return R.drawable.img_2021e_wheel_loader;
            default:                      return R.drawable.img_placeholder;
        }
    }

    // ---------- Optional: Capitalize words nicely ----------
    private String capitalizeWords(String str) {
        String[] words = str.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.length() > 0) {
                sb.append(Character.toUpperCase(w.charAt(0)))
                        .append(w.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
