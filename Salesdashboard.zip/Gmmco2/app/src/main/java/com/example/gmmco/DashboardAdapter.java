package com.example.gmmco;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class DashboardAdapter
        extends RecyclerView.Adapter<DashboardAdapter.ViewHolder> {

    private final Context       ctx;
    private final List<ModelItem> items;

    public DashboardAdapter(Context ctx, List<ModelItem> items) {
        this.ctx   = ctx;
        this.items = items;
    }

    /* ---------- ViewHolder creation ---------- */
    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                         int viewType) {
        View v = LayoutInflater.from(ctx)
                .inflate(R.layout.item_dashboard, parent, false);
        return new ViewHolder(v);
    }

    /* ---------- Binding ---------- */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        ModelItem m = items.get(pos);

        h.group .setText(m.getGroup());
        h.model .setText(m.getModel());
        h.north .setText("N: " + m.getNorth());
        h.south .setText("S: " + m.getSouth());
        h.east  .setText("E: " + m.getEast());
        h.west  .setText("W: " + m.getWest());
        h.total .setText("Total: " + m.getTotal());

        /* ‑‑‑ image handling (URL beats drawable) ‑‑‑ */
        if (m.getImageUrl() != null && !m.getImageUrl().isEmpty()) {
            Glide.with(ctx)
                    .load(m.getImageUrl())
                    .placeholder(R.drawable.img_placeholder)
                    .into(h.image);
        } else if (m.getImageRes() != 0) {
            h.image.setImageResource(m.getImageRes());
        } else {
            h.image.setImageResource(R.drawable.img_placeholder);
        }

        h.plusBtn.setOnClickListener(v ->
                new AlertDialog.Builder(ctx)
                        .setTitle("Sales Data")
                        .setMessage(
                                "Model: "        + m.getModel() + "\n\n" +
                                        "North Zone: "    + m.getNorth() + "\n"  +
                                        "South Zone: "    + m.getSouth() + "\n"  +
                                        "East Zone:  "    + m.getEast()  + "\n"  +
                                        "West Zone:  "    + m.getWest()  + "\n\n"+
                                        "Total: "         + m.getTotal())
                        .setPositiveButton("OK", null)
                        .show()
        );
    }

    @Override public int getItemCount() { return items.size(); }

    /* ---------- ViewHolder ---------- */
    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView group, model, north, south, east, west, total;
        Button plusBtn;

        ViewHolder(@NonNull View v) {
            super(v);
            image   = v.findViewById(R.id.image);
            group   = v.findViewById(R.id.group);
            model   = v.findViewById(R.id.model);
            north   = v.findViewById(R.id.north);
            south   = v.findViewById(R.id.south);
            east    = v.findViewById(R.id.east);
            west    = v.findViewById(R.id.west);
            total   = v.findViewById(R.id.total);
            plusBtn = v.findViewById(R.id.plusBtn);
        }
    }
}
